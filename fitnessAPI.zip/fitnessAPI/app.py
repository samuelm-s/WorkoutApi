from flask import make_response
from fpdf import FPDF

@app.route('/download_pdf')
def download_pdf():
    muscles = session.get('muscles', [])
    workouts_data = []

    for muscle in muscles:
        response = requests.get(
            f"https://api.api-ninjas.com/v1/exercises?muscle={muscle}",
            headers={"X-Api-Key": API_KEY}
        )
        if response.status_code == 200:
            workouts_data += response.json()

    # Generate PDF
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.set_text_color(56, 73, 89)

    pdf.cell(200, 10, txt="Workout Plan", ln=True, align='C')
    pdf.ln(10)

    for workout in workouts_data[:20]:
        pdf.multi_cell(0, 10, txt=f"{workout['name']} – {workout['type']} | Equipment: {workout['equipment']}")
        pdf.ln(1)

    response = make_response(pdf.output(dest='S').encode('latin1'))
    response.headers.set('Content-Disposition', 'attachment', filename='workout_plan.pdf')
    response.headers.set('Content-Type', 'application/pdf')
    return response
